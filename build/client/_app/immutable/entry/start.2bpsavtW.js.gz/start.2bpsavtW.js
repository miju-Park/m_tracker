import{a as t}from"../chunks/entry.Cs_RBm1p.js";export{t as start};
